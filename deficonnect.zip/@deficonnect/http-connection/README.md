# WalletConnect Http Connection

Http Connection for WalletConnect Providers

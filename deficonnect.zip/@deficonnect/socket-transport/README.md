# WalletConnect Socket Transport

Socket Transport for WalletConnect

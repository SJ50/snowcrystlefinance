# WalletConnect Core

Core Library for WalletConnect

This library is shared with the [Browser Client](https://www.npmjs.com/package/@walletconnect/browser) and [React-Native Client](https://www.npmjs.com/package/@walletconnect/react-native)

For more details, read the [documentation](https://docs.walletconnect.org)

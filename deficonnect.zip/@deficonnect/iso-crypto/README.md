# WalletConnect Isomorphic Crypto

Isomorphic Crypto for WalletConnect
